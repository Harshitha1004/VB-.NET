﻿Public Class Form1


    Dim t As Integer
    Dim s As Integer
    Dim m As Integer
    Sub displaytime()

        Label1.Text = Format(m, "00") + ":" + Format(s, "00") + ":" + Format(t, "00")

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Enabled = True


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Timer1.Enabled = False

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Label1.Text = "00" + ":" + "00" + ":" + "00"
        t = 0
        s = 0
        m = 0
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        t = t + 1
        displaytime()

        If t > 10 Then
            t = 0
            If s < 60 Then
                s = s + 1
            Else
                s = 0
                m = m + 1
            End If

        End If

    End Sub
End Class
